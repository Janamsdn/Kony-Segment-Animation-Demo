function initializeCopyFBox071e8af1ebb8340() {
    CopyFBox071e8af1ebb8340 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "70dp",
        "id": "CopyFBox071e8af1ebb8340",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "width": "100%"
    }, {}, {});
    CopyFBox071e8af1ebb8340.setDefaultUnit(kony.flex.DP);
    CopyFBox071e8af1ebb8340.add();
}