//actions.js file 
function AS_AppEvents_8a84016745d44ecba1d25abf940da40d() {
    return setGestureRecogniserToFrmfav.call(this);
}
function AS_Button_017ee2fd4cf24cb691ed81b98a450c4d() {}
function AS_Button_0848ac8a1d754db4a442d009b0b64eec() {}
function AS_Button_0db48114e4724fdfa4ee4aa816e9b983() {
    frmHome.show();
}
function AS_Button_1d68940a89594958a42bacc12f78bb08() {
    return removeRestaurents.call(this);
}
function AS_Button_22e8acb8adc447c6af2cf12b3878f275(eventobject) {
    undefined.show();
}
function AS_Button_379bbc50b54b4a8b85f2e807a34bf986() {}
function AS_Button_42732995e28e46cbb29e15fb18fd394c() {
    return testbuttononclick.call(this, widget, context);
}
function AS_Button_604431158ee04a4aa2b804008a9e706b() {
    frmHome.show();
}
function AS_Button_7b8cc19147914893a980985460699502() {
    return markAsFavouriteRestaurent.call(this);
}
function AS_Button_80b8d034a55549c5ae72f76855cbf8ff() {
    frmLogin.show();
}
function AS_Button_8a58f339461b44788740028b23efa6a1() {}
function AS_Button_b255b3f1793d49658a396e8698e1322d() {}
function AS_Button_b6b561388e5942b285974b7aaf09ab9f() {
    frmFavorite.show();
}
function AS_Button_ba8009aaff6d48da9c9a68d09def217f() {
    frmHome.show();
}
function AS_Button_ccf20d6307034e66891dbd30f65a3d7e() {
    frmLogin.show();
}
function AS_Button_dbf5be30e7b5481ca6c50234170f4002() {
    return setRestaurents.call(this);
}
function AS_Button_ddc4d74f8fdb473d8d278d35b9e59929() {}
function AS_Button_e72209a6be7d4233a2f85ec7a4ad4d41() {}
function AS_Button_eca2998968164527addd369d01ff55af() {
    frmHome.show();
}
function AS_FlexContainer_8d59f70955864c1abe0b096c3e086e61() {
    deleteSegRow();
}
function AS_FlexContainer_bc024898cde84b94b16f917d8ab94faf() {
    return deleteSegRow.call(this, this, context);
}
function AS_Form_24f504db645f4df0a3e742c828e241b5() {
    return animateLoginWidget1.call(this);
}
function AS_Form_7e44589989664a03ba9d3fb4f40ae78d() {
    setFavoriteRestaurent1.call(this);
    setDeleteButtonCallBack();
}
function AS_Form_9668d973e74e4b14b3ed226faa287aa5() {
    //setGestureRecogniserToFrmHome();
    removeRestaurents();
}
function AS_Form_cc6d3719edab4037807254f5a17c49d2() {
    kony.application.setApplicationBehaviors({
        applyMarginPaddingInBCGMode: false,
        adherePercentageStrictly: true,
        retainSpaceOnHide: true,
        marginsIncludedInWidgetContainerWeight: true,
        APILevel: 6800,
        hideDefaultLoadingIndicator: true,
    })
}
function AS_Form_d5e1ebbbfcca4bb5a2d80b58975865d4() {
    setRestaurents();
    onRowDisplayFunction();
}
function AS_Image_03289ea1a97941f2b212711370ecdef7() {}
function AS_Segment_df46bfdce97f4382bcd85438f80ebb5b() {
    showRestaurentDetails1();
}
function AS_TitleBar_030774e7928a4470868971424d994218() {
    return setRestaurents.call(this);
}
function AS_TitleBar_f32cc18519a749a59bb578c932852e95() {
    return removeRestaurents.call(this);
}