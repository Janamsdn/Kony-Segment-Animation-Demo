function initializeFBox064a1b8498c1348() {
    FBox064a1b8498c1348 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "60dp",
        "id": "FBox064a1b8498c1348",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "width": "100%"
    }, {}, {});
    FBox064a1b8498c1348.setDefaultUnit(kony.flex.DP);
    FBox064a1b8498c1348.add();
}