function AS_Button_dbf5be30e7b5481ca6c50234170f4002() {
    return setRestaurents.call(this);
}