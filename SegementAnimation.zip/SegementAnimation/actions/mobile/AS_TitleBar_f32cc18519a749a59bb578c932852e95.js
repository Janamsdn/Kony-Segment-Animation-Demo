function AS_TitleBar_f32cc18519a749a59bb578c932852e95() {
    return removeRestaurents.call(this);
}