function AS_Button_7b8cc19147914893a980985460699502() {
    return markAsFavouriteRestaurent.call(this);
}