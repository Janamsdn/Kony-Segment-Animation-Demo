function AS_Segment_df46bfdce97f4382bcd85438f80ebb5b() {
    showRestaurentDetails1();
}