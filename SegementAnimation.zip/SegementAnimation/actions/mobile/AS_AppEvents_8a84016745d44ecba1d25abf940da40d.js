function AS_AppEvents_8a84016745d44ecba1d25abf940da40d() {
    return setGestureRecogniserToFrmfav.call(this);
}