function AS_TitleBar_030774e7928a4470868971424d994218() {
    return setRestaurents.call(this);
}