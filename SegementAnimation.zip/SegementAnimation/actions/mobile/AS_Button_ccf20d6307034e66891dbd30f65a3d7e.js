function AS_Button_ccf20d6307034e66891dbd30f65a3d7e() {
    frmLogin.show();
}