function AS_Form_cc6d3719edab4037807254f5a17c49d2() {
    kony.application.setApplicationBehaviors({
        applyMarginPaddingInBCGMode: false,
        adherePercentageStrictly: true,
        retainSpaceOnHide: true,
        marginsIncludedInWidgetContainerWeight: true,
        APILevel: 6800,
        hideDefaultLoadingIndicator: true,
    })
}