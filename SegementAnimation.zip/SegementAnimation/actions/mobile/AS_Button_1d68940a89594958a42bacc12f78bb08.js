function AS_Button_1d68940a89594958a42bacc12f78bb08() {
    return removeRestaurents.call(this);
}