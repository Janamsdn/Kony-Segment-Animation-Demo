function AS_Form_f00e3b0bc2a146b085655cd3fa9800ac(eventobject) {
    return setGestureRecogniserToFrmfav.call(this);
}