function AS_Form_24f504db645f4df0a3e742c828e241b5() {
    return animateLoginWidget1.call(this);
}