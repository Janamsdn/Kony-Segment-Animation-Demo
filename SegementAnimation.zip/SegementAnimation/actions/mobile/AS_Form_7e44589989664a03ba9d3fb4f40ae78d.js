function AS_Form_7e44589989664a03ba9d3fb4f40ae78d() {
    setFavoriteRestaurent1.call(this);
    setDeleteButtonCallBack();
}