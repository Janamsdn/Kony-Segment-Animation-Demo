function AS_Form_d5e1ebbbfcca4bb5a2d80b58975865d4() {
    setRestaurents();
    onRowDisplayFunction();
}