function AS_Button_b6b561388e5942b285974b7aaf09ab9f() {
    frmFavorite.show();
}