function AS_Form_9668d973e74e4b14b3ed226faa287aa5() {
    //setGestureRecogniserToFrmHome();
    removeRestaurents();
}